UPDATE `emulator_texts` SET `value` = 'Cu cu, cucu, cucu.' WHERE `emulator_texts`.`key` = 'pirate_parrot.message.0';
UPDATE `emulator_texts` SET `value` = 'Once was a capt whos ship this was, then i came along and mutinied, just so ye better watch where i be swooping.' WHERE `emulator_texts`.`key` = 'pirate_parrot.message.1';
UPDATE `emulator_texts` SET `value` = 'Ye flying the old jolly bobba, better av the goal to be a real pirate matey!' WHERE `emulator_texts`.`key` = 'pirate_parrot.message.2';
UPDATE `emulator_texts` SET `value` = 'Ye think im ya friend, keep in mind friends can always betray ye, enemies are the ones that stay the same.' WHERE `emulator_texts`.`key` = 'pirate_parrot.message.3';
UPDATE `emulator_texts` SET `value` = 'Arr arr arr, dont be silly, we werent talking about ye booti-by... dont give me that look ye scalywag.' WHERE `emulator_texts`.`key` = 'pirate_parrot.message.4';

INSERT INTO `emulator_texts` (`key`, `value`) VALUES
('xmas14_santateller.message.0', 'Merry Christmas!'),
('xmas14_santateller.message.1', 'Did you know i have a zen filled holiday season.'),
('xmas14_santateller.message.2', 'Everyday is a surprise.'),
('xmas14_santateller.message.3', 'All i want for christmas is cookies. tons of cookies.'),
('xmas14_santateller.message.4', 'Inner peace starts with an hc subscription.'),
('xmas14_santateller.message.5', 'Dont get your tinsel in a tangle.'),
('xmas14_santateller.message.6', 'What do snowmen eat for lunch? ice bergers.'),
('xmas14_santateller.message.7', 'I heard rudolph stole that nose from a Wulles clown.'),
('xmas14_santateller.message.8', 'Ho ho ho-ohmmmmm.'),
('xmas14_santateller.message.9', 'Or is that just my eyes?!This seashell is whispering sweet nothings in my ear. oh, its got a crab inside!'),
('xmas14_santateller.message.10', 'Be the builders block.'),
('xmas14_santateller.message.11', 'What if life isnt all about whos around it.'),
('xmas14_santateller.message.12', 'Its not about whats under the tree, its about whos around it.'),
('jungle_c16_radio.message.0', 'Do not get bitten by gnats, they transmit Ebola.'),
('jungle_c16_radio.message.1', 'News - piccolo is rumoured to have quit habbo to travel the world! Its just a rumour at the moment...'),
('jungle_c16_radio.message.2', 'Sure to check out this weeks edition of jungle survival tips.'),
('jungle_c16_radio.message.3', 'Warning for all those habbos stranded in the jungle!'),
('jungle_c16_radio.message.4', 'We heard piccolo got lost in the jungle and remains there to this day...'),
('jungle_c16_radio.message.5', 'Frank. hes looking 100% fresh in his survival kit today, habbos!'),
('pirate_parrot.message.5', 'Go bring me a flagon a bubble juice, ye scurvy dog!'),
('pirate_parrot.message.6', 'Jones aint got nuttin on me, bucko, ye can bet ye breeches.');